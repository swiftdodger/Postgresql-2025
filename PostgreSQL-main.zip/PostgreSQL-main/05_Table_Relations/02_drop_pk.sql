ALTER TABLE
	products
DROP CONSTRAINT
	products_pkey;
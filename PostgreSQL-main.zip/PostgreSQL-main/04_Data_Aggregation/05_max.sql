SELECT
	MAX(age) AS maximum_age
FROM
	wizard_deposits
SELECT
	COUNT(*)
FROM
	wizard_deposits
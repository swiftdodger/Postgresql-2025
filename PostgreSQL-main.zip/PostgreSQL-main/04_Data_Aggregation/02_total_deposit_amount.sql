SELECT
	SUM(deposit_amount)
FROM
	wizard_deposits
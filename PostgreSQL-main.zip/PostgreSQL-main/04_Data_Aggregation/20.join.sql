SELECT
	*
FROM
	departments
JOIN
	employees
ON 
	employees.department_id = departments.id
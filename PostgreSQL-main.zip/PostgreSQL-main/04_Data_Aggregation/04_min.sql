SELECT
	MIN(deposit_charge) AS minimum_deposit_charge
FROM
	wizard_deposits
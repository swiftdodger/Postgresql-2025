SELECT
	AVG(multiplication) AS avarage_value
FROM
	bookings_calculation

SELECT
	longitude,
	ABS(longitude) AS "abs"
FROM
	apartments;
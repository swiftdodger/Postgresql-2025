SELECT
	SUBSTRING(description FROM 5) AS "substring"
-- 	RIGHT(description, -4)
FROM
	currencies;
ALTER TABLE minions_info
DROP COLUMN age;
ALTER TABLE minions_info
RENAME COLUMN salary TO banana;

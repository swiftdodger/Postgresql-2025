SELECT
	name,
	task,
	email,
	banana
FROM 
	minions_info;
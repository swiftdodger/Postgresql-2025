ALTER TABLE minions
RENAME TO minions_info;
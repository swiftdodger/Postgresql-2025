ALTER VIEW
	view_addresses
RENAME TO
	view_employee_addresses_info;
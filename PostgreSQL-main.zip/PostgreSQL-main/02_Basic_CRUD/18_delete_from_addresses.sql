DELETE FROM
	addresses
WHERE
	city_id IN (5, 17, 20, 30);